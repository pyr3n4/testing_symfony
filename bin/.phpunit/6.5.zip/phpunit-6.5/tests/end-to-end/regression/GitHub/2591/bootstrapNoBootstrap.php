<?php
ini_set('display_errors', 0);
ini_set('log_errors', 1);

$globalString                          = 'Hello';

// require __DIR__ . '/../../../../bootstrap.php';
